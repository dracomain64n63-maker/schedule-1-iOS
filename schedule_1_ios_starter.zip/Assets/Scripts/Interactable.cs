using UnityEngine;

public class Interactable : MonoBehaviour
{
    [SerializeField] private string interactionLabel = "Interact";

    public string InteractionLabel => interactionLabel;

    public virtual void Interact()
    {
        Debug.Log($"Interacted with {gameObject.name}");
    }
}
