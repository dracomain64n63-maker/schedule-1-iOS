using UnityEngine;

[RequireComponent(typeof(CharacterController))]
public class FirstPersonController : MonoBehaviour
{
    [Header("References")]
    public Camera playerCamera;

    [Header("Movement")]
    public float moveSpeed = 4.5f;
    public float gravity = -18f;

    [Header("Look")]
    public float lookSensitivity = 0.12f;
    public float maxLookAngle = 85f;

    private CharacterController characterController;
    private Vector2 moveInput;
    private Vector2 lookInput;
    private float verticalVelocity;
    private float cameraPitch;

    private void Awake()
    {
        characterController = GetComponent<CharacterController>();
        if (playerCamera == null)
            playerCamera = GetComponentInChildren<Camera>();
    }

    private void Update()
    {
#if UNITY_EDITOR || UNITY_STANDALONE
        moveInput = new Vector2(Input.GetAxisRaw("Horizontal"), Input.GetAxisRaw("Vertical"));
        if (Input.GetMouseButton(1))
        {
            lookInput = new Vector2(Input.GetAxis("Mouse X"), Input.GetAxis("Mouse Y"));
            Cursor.lockState = CursorLockMode.Locked;
        }
        else
        {
            lookInput = Vector2.zero;
            Cursor.lockState = CursorLockMode.None;
        }

        if (Input.GetKeyDown(KeyCode.E))
            TryInteract();
#endif
        Move();
        Look();
        lookInput = Vector2.zero;
    }

    public void SetMoveInput(Vector2 value) => moveInput = Vector2.ClampMagnitude(value, 1f);
    public void SetLookInput(Vector2 value) => lookInput = value;

    private void Move()
    {
        Vector3 move = transform.right * moveInput.x + transform.forward * moveInput.y;
        characterController.Move(move * moveSpeed * Time.deltaTime);

        if (characterController.isGrounded && verticalVelocity < 0f)
            verticalVelocity = -2f;

        verticalVelocity += gravity * Time.deltaTime;
        characterController.Move(Vector3.up * verticalVelocity * Time.deltaTime);
    }

    private void Look()
    {
        if (playerCamera == null) return;

        transform.Rotate(Vector3.up * lookInput.x * lookSensitivity * 100f);
        cameraPitch = Mathf.Clamp(cameraPitch - lookInput.y * lookSensitivity * 100f,
                                  -maxLookAngle, maxLookAngle);
        playerCamera.transform.localRotation = Quaternion.Euler(cameraPitch, 0f, 0f);
    }

    public void TryInteract()
    {
        if (playerCamera == null) return;

        if (Physics.Raycast(playerCamera.transform.position,
                            playerCamera.transform.forward,
                            out RaycastHit hit, 3f))
        {
            Interactable interactable = hit.collider.GetComponentInParent<Interactable>();
            if (interactable != null)
                interactable.Interact();
        }
    }
}
