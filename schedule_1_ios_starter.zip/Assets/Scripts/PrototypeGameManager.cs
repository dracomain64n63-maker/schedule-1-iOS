using UnityEngine;

public class PrototypeGameManager : MonoBehaviour
{
    public static PrototypeGameManager Instance { get; private set; }

    [SerializeField] private int startingMoney = 500;
    public int Money { get; private set; }

    private void Awake()
    {
        if (Instance != null && Instance != this)
        {
            Destroy(gameObject);
            return;
        }

        Instance = this;
        Money = Mathf.Max(0, startingMoney);
        Debug.Log($"Prototype started. Starting balance: ${Money}");
    }

    public bool TrySpend(int amount)
    {
        if (amount < 0 || Money < amount) return false;
        Money -= amount;
        return true;
    }

    public void AddMoney(int amount)
    {
        if (amount > 0) Money += amount;
    }
}
