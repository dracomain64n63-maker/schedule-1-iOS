using UnityEngine;

public class BusinessTerminal : Interactable
{
    public override void Interact()
    {
        Debug.Log("Business terminal opened. Management UI will be added in the next milestone.");
    }
}
