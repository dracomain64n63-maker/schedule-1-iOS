Create and save the Main scene here in Unity Editor. Follow the setup steps in the root README.
